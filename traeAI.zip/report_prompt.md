Generate a full academic report in R Markdown.

1. Load datasets from /data/*.csv
2. Answer the assignment questions
3. Provide R code, tables, graphs
4. Create a compiled HTML report
